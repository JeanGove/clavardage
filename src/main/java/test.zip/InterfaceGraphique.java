//package clavardage;

public class InterfaceGraphique {

}
